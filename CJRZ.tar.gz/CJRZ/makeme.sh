#!/bin/bash

aclocal
if [ $? = 0 ]
then
	echo " aclocal Complete! " >> ./installStat.txt
fi

autoconf
if [ $? = 0 ]
then
	echo " autoconf Complete! " >> ./installStat.txt
fi

automake --add-missing --foreign --copy
if [ $? = 0 ]
then
	echo " automake Complete! " >> ./installStat.txt
fi

./configure
if [ $? = 0 ]
then
	echo " ./configure Complete! " >> ./installStat.txt
fi

make
if [ $? = 0 ]
then
	echo " make Complete! " >> ./installStat.txt
fi

make install
if [ $? = 0 ]
then
	echo " make install Complete! " >> ./installStat.txt
fi

cp ./Function_data.txt ./Header_data.txt /usr/local/bin/
chmod 4755 /usr/local/bin/clib
if [ $? = 0 ]
then
	echo " install All Complete! " >> ./installStat.txt
fi


nl ./installStat.txt
