/***
* Project Name : Linked List를 활용한 C Library 검색기
* Project Team : CJRZ (양성수, 최재린, 이한결, 최재근)
* Last Update : 2018.08.06
***/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* 전처리
 *  TRUE :	 		참값
 *  FIRSTWORD :		문자열의 첫글자
 *  SAMESTR : 		문자열 비교 시 같은 문자열
 *  HDSIZE :		index 용 헤더 배열의 길이
 *  FLSIZE :  		index 용 함수 배열의 길이
 *  NAMESIZE : 		함수 이름 히스토리 출력 시 사용되는 길이
 *  INPUTBURRERSIZE : 	입력 값 사이즈
 *  ASCIIANUM :		a의 아스키코드 값
 *  READSIZE :		파일 읽을 때 사용하는 버퍼의 사이즈
 *  HISTSIZE :		힘수 이름 히스토리의 배열 사이즈
 */

#define TRUE 1
#define FIRSTWORD 0
#define SAMESTR 0
#define HDSIZE 24
#define FLSIZE 26
#define NAMESIZE 30
#define INPUTBUFFERSIZE 50
#define ASCIIANUM 97
#define READSIZE 1000
#define HISTSIZE 100


/*
 FunctionList FL : 함수의 정보를 담을 구조체
 	flName : 함수의 이름
 	flPtype : 함수의 원형 (프로토 타입)
 	flHName : 함수의 헤더 이름
 	flInfo : 함수의 기능 설명
 	alNext : 알파뱃 순으로 연결된 다음 노드의 주소
	hdNext : 헤더 순으로 연결된 다음 노드의 주소
			
 HeaderList HL : 헤더의 정보를 담을 구조체
	hdName : 헤더의 이름
	hdInfo : 헤더의 설명
	flAddr : 포함된 함수의 첫번째 노드 주소
*/

typedef struct FunctionList FL;
typedef struct HeaderList HL;

struct FunctionList {

	char *flName;
	char *flPtype;
	char *flHName;
	char *flInfo;

	struct FunctionList *alNext;
	struct FunctionList *hdNext;

	struct HeaderList *hdAddr;

};

struct HeaderList {

	char *hdName;
	char *hdInfo;

	struct FunctionList *flAddr;

};


/* 전역 변수
 * flarr :	알파뱃 순으로 검색을 위한 index 배열
 * hdarr : 	헤더 순으로 검색을 위한 index 배열
*/

FL* flarr[FLSIZE];
HL* hdarr[HDSIZE];

/* 함수 설명
 * void link_to_header(FL *funcNode);		헤더 index 배열부터 노드 연결	
 * void link_at_alphabet(FL *funcNode);		함수 index 배열부터 노드 연결
 * void read_function_data();				파일에서 함수 데이터를 읽어와 노드에 저장
 * void read_header_data();					파일에서 헤더 데이터를 읽어와 노드에 저장
 * void print_menu();						메인 메뉴 출력
 * void function_search_menu();				함수 이름을 입력 받아 함수 검색
 * void header_search_menu();				헤더 번호를 입력 받아 헤더 검색
 * void find_function_data(char *findFuncName);	함수 히스토리 출력 및 함수 위치 검색
 * void print_function_data(FL *temp);		함수 정보 출력
 * void print_header_data(int index);		헤더 정보 출력
 * void quit_program();						프로그램 종료
*/

void link_to_header(FL *funcNode);
void link_at_alphabet(FL *funcNode);
void read_function_data();
void read_header_data();
void print_menu();
void function_search_menu();
void header_search_menu();
void find_function_data(char *findFuncName);
void print_function_data(FL *temp);
void print_header_data(int index);
void quit_program();
